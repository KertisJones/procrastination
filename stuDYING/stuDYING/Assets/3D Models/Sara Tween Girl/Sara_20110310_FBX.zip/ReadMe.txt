Sara Tween Girl
Version 1.1

This model will be part of Khayyam scene builder and poser package. For more information look at
Khayyam development blog (http://poseablegeometry.blogspot.com/) and Floyd project website at
SourceForge (http://floyd.sourceforge.net/)


Features

Vertices: 6430
Polygons: 6162
Clothes: panties, bra, shirt, skirt, socks, stockings, shoes
Skeleton: fully rigged
Textures: included


Notes

1. Blender file uses mirror modifier for most of its symmetrical parts. So if you need full UV unwrapping,
mirror has to be collated first.
2. Clothes use simple repeated textures and some color-only materials.
3. Clothes and hair are bound to body skeleton so they will be deformed extensively. In later version I plan
to add extra bones for hair and skirt.


Changelog

2011/03/10 version 1.1
Remodeled face topology and made mouth more realistic.


Copyright (C) Lauris Kaplinski 2011

You can use the model freely in your creations (renders, games...) as long as you do not distribute it
in editable form. If you want to redistribute it in original or derived form, either as standalone model
as part of model collection, ask me first.

Lauris Kaplinski
lauris@kaplinski.com





