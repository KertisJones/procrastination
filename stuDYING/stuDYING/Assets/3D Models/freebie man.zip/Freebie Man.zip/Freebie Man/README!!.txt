Thank you for downloading this freebie. i'm sure you will have hours of fun animating him.
I built this model as a learning experiment to learn animation in character studio. So far, i have learned allot!!!. I figured, why not make this guy free so more people can learn and have fun animating. 

Anyway, to help me out, please leave a rating and comment on turbosquid. I rely on these to help boost sales for my other models. 

Thanks so much in advance

Henleyernest.


ps. I also included tones of free animations for you to use with this guy. 

Cheers.

pps. in the renders folder, you'll see examples of how much fun can b made using this guy, as well as other models for download at turbosquid.
Remember, please leave a ranking and a comment.